# Воспроизведение третьего раунда

Числовые слои и доказательства используют сохранённые первичные байты. Для точного повторения новые сетевые обращения не нужны. Новая загрузка с обновляемого сайта может дать другую версию документа.

## Получить поставку

Нужен репозиторий `sberindex-hackathon-2026/municipal-economic-profiles`, доступный участникам команды. Пять ZIP находятся в [релизе](https://github.com/sberindex-hackathon-2026/municipal-economic-profiles/releases/tag/data-round3-2026-09-16). Их размеры и SHA-256 — в `delivery/summary.json`; внутренние списки файлов — в `delivery/*.manifest.json`.

```powershell
gh release download data-round3-2026-09-16 --repo sberindex-hackathon-2026/municipal-economic-profiles --pattern '*.zip' --dir round3-downloads
```

ZIP содержат пути от корня рабочего пространства, например `work/data-round3/cases/...` и `work/data-round3/economy-server/...`. Распаковать их следует в корень рабочего пространства, внутри которого репозиторий находится в `outputs/municipal-economic-profiles`. Альтернативное расположение допускается, если явно изменить аргументы путей. Сначала сверить SHA архивов; не перезаписывать прежние исследовательские результаты.

## Экономический слой: без сети

Команды из каталога `enrichment` репозитория, Python 3.12 и существующий `uv.lock`:

```powershell
uv sync --frozen
uv run --frozen python -m sber_enrichment.round3_economy --links ../reports/data_round2/sector/bulk/year_specific_links.csv --output ../../../work/data-round3/economy-offline-new --cache ../../../work/data-round3/economy-server/data-round3-economy-20260916-cache --cache-only
uv run --frozen python scripts/verify_round3_economy.py --data ../../../work/data-round3/economy-offline-new --cache ../../../work/data-round3/economy-server/data-round3-economy-20260916-cache --links ../reports/data_round2/sector/bulk/year_specific_links.csv --out ../../../work/data-round3/economy-offline-new/independent_cell_QA.json
uv run --frozen pytest -q
```

Ожидается 12 096 строк, 10 829 чисел, 22 исходных маркера и 1245 не принятых/не возвращённых ячеек. В `source_cells.csv` 10 880 строк: 29 лишних сочетаний исходного кода и года отсутствуют в годовой связи и не принимаются в панель. Эта разница воспроизводится через anti-join по `source_region_url, source_oktmo, year, indicator_id` между `source_cells.csv` и ключами панели.

Каноническая сборка выполнена на Linux. Повтор на Windows дал идентичные значения и порядок строк в трёх CSV и побайтово идентичный Parquet; окончания строк CSV различаются по платформе. Сетевые счётчики `summary.json` также ожидаемо отличаются. Контрольный результат — `economy/offline_replay_QA.json`. Независимый проверяющий скрипт читает исходные CSV и формы, проверяет кодовые индексы, запросы, периоды, единицы, буквальные ячейки и полную ожидаемую сетку.

Первый серверный прогон и итоговая сборка сохранены отдельно. Первый получил 403 ответа, итоговая версия использовала их кэш и получила ещё 13. Старую версию кода сохраняет `work/data-round3/economy/implementation_initial.py`; текущий код находится в репозитории. Это разбор проверенных различий региональных форм, а не пересмотр чисел или заполнение пропусков.

## Остальные разделы

- [Местные кейсы](cases/REPRODUCE.md): фиксированные локаторы PDF/DOCX, 53 записи. Числовое воспроизведение не требует OCR-модели.
- [МСП](sme/README.md): `--derive-only`, три таблицы, проверка датировки. Муниципального кодового присоединения нет.
- [География](geography/README.md): offline-сборка официальных дат и 131 пары кодов; правовые списки и реестры не соединяются по неявному сходству названий.
- [Серверный поиск](search/README.md): архив сохраняет 9 исходных тел, ответы SearXNG и исходы вызовов DeepSeek. Повтор платных модельных вызовов не требуется для проверки доставленных чисел.

Архивы построены существующим `enrichment/scripts/package_round2_delivery.py` по пяти опубликованным allowlist из `delivery/`. Название упаковщика историческое: он не меняет данные второго раунда. Он проверяет каждый путь, не допускает повторных путей в ZIP, сканирует содержимое на шаблоны секретов и сверяет каждый извлечённый файл с SHA-256. В данном вызове `--work` указывает на корень рабочего пространства, поскольку пути allowlist начинаются с `work/`.

Старые исследовательские результаты остаются отдельными неизменёнными версиями. Воспроизведение третьего сбора не запускает оценку моделей, не меняет маски географии и не превращает найденные документы в причинные объяснения.
